package figuras;

import java.awt.Color;

public class Cuadrado extends Rectángulo{

public Cuadrado (double x, double y, Color color, double lado){
super (x, y, color, lado, lado);
}
}
